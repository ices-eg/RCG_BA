#' Create major/minor port allocations
#'
#' Function to allocate landing ports according to variables "landWt" or "fishTripId".
#' Ports will be sorted according to the selected variable and the top percentage will be allocated as major ports.
#' The remaining ports will be allocated as minor ports.
#'
#' @param dat landings dataframe
#' @param portFrame portFrame dataframe with unique port entries
#' @param by the selected variable to use for assigning ports: "landWt" or "fishTripId"
#' @param percentMajor the percentage of the selected variable to be included in the definition of major ports
#' @param areaSelection (optional) option to include a geographic restriction based on the variable "area"
#' @param ISSCAAPSelection (optional) option to include a species type restriction based on the variable "ISSCAAP"
#'
#' @return vector with major/minor port allocations, with length equal to portFrame dataframe rows
#'
#' @examples
#'
#' @author Jessica Craig \email{jessica.craig@gov.scot}
#'
#' @export

createPortAllocations <-
  function(dat, portFrame = portFrame, by = "landWt", percentMajor = 90, areaSelection = widerNSea, ISSCAAPSelection = demISSCAAP){

  dat <- dat[dat$area %in% areaSelection & dat$ISSCAAP %in% ISSCAAPSelection,]
  rank_landLoc <- rankingFp2Variable(dat, grouping_variable = "landLoc")

  if(by == "landWt"){portAlloc <- rank_landLoc$landLoc[which(rank_landLoc$cum_per_land <= percentMajor)]}
  if(by == "fishTripId"){portAlloc <- rank_landLoc$landLoc[which(rank_landLoc$cum_per_trips <= percentMajor)]}

  dat$landLocType[dat[,"landLoc"] %in% portAlloc] <- "major"
  dat$landLocType[!dat[,"landLoc"] %in% portAlloc] <- "minor"

  portFrame$newPortAllocation <- "minor"
  portFrame$newPortAllocation <- dat$landLocType[match(portFrame$loCode,dat$landLoc)]

  print(table(portFrame$newPortAllocation))
  return(portFrame$newPortAllocation)
}
