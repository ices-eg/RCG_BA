#' Bias plot by domain
#'
#'
#' @param calcs list of summary statistics output from the function \code{"calcRes"}
#'
#' @return Bias plot by domain
#'
#' @examples
#'
#' @author Alastair Pout \email{apout@marlab.ac.uk} and Jessica Craig \email{jessica.craig@gov.scot}
#'
#' @export

biasPlotDom <-
  function(calcs,...)
{
  #-----------bias plot------------------------------
  dots <- list(...)
  if (is.null(dots$ylim))dots$ylim <-c(-20,20)
  if (is.null(dots$xlab))dots$xlab <-"Sample size"
  if (is.null(dots$ylab))dots$ylab <-"% deviation"
  if (is.null(dots$cex))dots$cex <- 0.5

  plot(calcs$domSampSize,calcs$domBiasEst,type="n",ylim=dots$ylim,xlab=dots$xlab,ylab=dots$ylab)
  points(calcs$domSampSize,calcs$domBiasEst,pch=16,cex=0.7)
  text(calcs$domSampSize,calcs$domBiasEst,names(calcs$domSampSize),cex=dots$cex,pos=1)
  abline(h=c(-10,-5,5,10),col="grey")
  abline(h=c(0),col="grey",lty=2)
  #------------------------------------------------------------
  return("All Done")
}

