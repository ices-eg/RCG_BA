#' Function to summarise and rank dataframe
#'
#' This functions can be used for the selection of strata by criteria of % of landings or % of trips
#' e.g. landLoc
#' requires: tidyverse package
#'
#' @param data landings dataframe
#' @param grouping_variable variable by which to summarise, e.g. landLoc
#'
#' @return
#'
#' @examples
#'
#' @author Jose Rodriguez \email{jose.rodriguez@ieo.es}
#'
#' @export

rankingFp2Variable <-
  function(data, grouping_variable = landLoc) {

  library(tidyverse)
    ranking <- data %>%
        group_by_(grouping_variable) %>%
        summarise(landings = sum(landWt), n_trips = n_distinct(fishTripId)) %>%
        arrange(desc(landings)) %>%
        mutate(total_lan = sum(landings)) %>%
        mutate(per_land = round(landings*100/total_lan, 4)) %>%
        mutate(cum_per_land = cumsum(per_land)) %>%
        arrange(desc(landings)) %>%
        mutate(rank_land = 1:n()) %>%
        arrange(desc(n_trips)) %>%
        mutate(total_trips = sum(n_trips)) %>%
        mutate(per_trips = n_trips*100/total_trips) %>%
        mutate(cum_per_trips = cumsum(per_trips)) %>%
        arrange(desc(n_trips)) %>%
        mutate(rank_trips = 1:n()) %>%
        arrange(desc(landings)) %>%
        select(grouping_variable, landings, per_land, cum_per_land, rank_land, n_trips, per_trips, cum_per_trips, rank_trips) %>%
        print(n = nrow(.))

}


