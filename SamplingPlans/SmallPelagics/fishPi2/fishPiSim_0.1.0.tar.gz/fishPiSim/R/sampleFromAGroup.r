#' Function that samples from a group
#'
#' This function is used within the function \code{runSim}
#'
#' @param x defines the sampling units to be sampled
#' @param y defines the groups from which to sample
#' @param nsize a vector giving the sample sizes in each group, named according to the unique values in y. The values in y need to match the names of nsize
#'
#' @return
#'
#' @examples
#'
#' @author Alastair Pout \email{apout@marlab.ac.uk}
#'
#' @export

sampleFromAGroup <-
  function(x,y,nsize)
    {

  nGroup <- length(nsize)
  xSamp <- NULL
  for (i in 1:nGroup) {
    indx <- unique(x[which(y==names(nsize)[i])])
    samp <- sample(indx,size=nsize[i],replace=FALSE)
    if (i==1) {
      xSamp <- samp
    } else {
      xSamp <- c(xSamp,samp)
    }
  }
  return(xSamp)
}
