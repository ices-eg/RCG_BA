#' Function that creates the objects to hold the simulation results
#'
#' @param data landings dataframe
#' @param nsim integer determining number of simulations to be run
#' @param simName a character vector for the naming of the simulation
#'
#' @return resObj - a list object with various vectors for holding the simulation results
#'
#' @examples
#'
#' @author Alastair Pout \email{apout@marlab.ac.uk}
#'
#' @export

setUpSim <-
  function(nsim,data,simName="testSim")
{


# the unique species, country
sppList <- sort(unique(data$sppFAO))
ctryList <- sort(unique(data$landCtry))
strataList <- sort(unique(data$psuStratum))
domainLevels <-as.character(sort(unique(data$domainFac)))
# the number of species, country and stratum
Nspp <- length(sppList)
Nctry <-length(ctryList)
Nstrat <-length(strataList)
Ndomain <-length(domainLevels)

# array to hold the simulation
# total and SE  standard error note one total estimate for all
totalEst <- array(NA,dim=c(nsim,2))
# total and se for the spp  - assumes we want to estimate for spp
sppEst <- array(NA,dim=c(Nspp,2,nsim))
# this records the sample size by species
sppNumber <- array(NA,dim=c(nsim,Nspp))
# this records the number of sampled fishing trips
fishTripNumber <- array(NA,dim=c(nsim))
dimnames(sppNumber)[[2]] <- sppList
dimnames(sppEst)[[1]] <- sppList
sampRowNames <- list()

domainEst <- array(NA,dim=c(length(domainLevels),2,nsim))
dimnames(domainEst)[[1]] <- domainLevels
# this records the sample size by domains
domainNumber <- array(NA,dim=c(nsim,Ndomain))
dimnames(domainNumber)[[2]] <- domainLevels
# estimates by country and stratum
ctryEst <- array(NA,dim=c(Nctry,2,nsim))
dimnames(ctryEst)[[1]] <- ctryList
strataEst <- array(NA,dim=c(Nstrat,2,nsim))

if(length(strataList)>1)dimnames(strataEst)[[1]] <- strataList


resObj <-list("sampRowNames"=sampRowNames,"sppEst"=sppEst,"sppNumber"=sppNumber,
"fishTripNumber"=fishTripNumber,"ctryEst"=ctryEst,"strataEst"=strataEst,"domainEst"=domainEst,"domainNumber"=domainNumber,"totalEst"=totalEst,"pop"=data,"sppList"=sppList,"ctryList"=ctryList,"strataList"=strataList,"domainList"=domainLevels,"simName"=simName)
return(resObj)
}
