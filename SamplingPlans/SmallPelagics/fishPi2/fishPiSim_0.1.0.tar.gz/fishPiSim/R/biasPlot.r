#' Bias plot by species
#'
#'
#' @param calcs list of summary statistics output from the function \code{"calcRes"}
#'
#' @return Bias plot by species
#'
#' @examples
#'
#' @author Alastair Pout \email{apout@marlab.ac.uk}
#'
#' @export


biasPlot <-
  function(calcs,...)
{
#-----------bias plot------------------------------
dots <- list(...)
if (is.null(dots$ylim))dots$ylim <-c(-20,20)
if (is.null(dots$xlab))dots$xlab <-"Sample size"
if (is.null(dots$ylab))dots$ylab <-"% deviation"
if (is.null(dots$cex))dots$cex <- 0.7

plot(calcs$sppSampSize,calcs$sppBiasEst,type="n",ylim=dots$ylim,xlab=dots$xlab,ylab=dots$ylab)
points(calcs$sppSampSize,calcs$sppBiasEst,pch=16,cex=0.7)
#text(sppSampSize,sppBiasEst,names(sppSampSize),cex=0.7)
text(calcs$sppSampSize,calcs$sppBiasEst,names(calcs$sppSampSize),cex=dots$cex,pos=1)
abline(h=c(-10,-5,5,10),col="grey")
abline(h=c(0),col="grey",lty=2)
#------------------------------------------------------------
return("All Done")
}
