#' Variance plot by species
#'
#'
#' @param calcs list of summary statistics output from the function \code{"calcRes"}
#'
#' @return Variance plot by species
#'
#' @examples
#'
#' @author Alastair Pout \email{apout@marlab.ac.uk}
#'
#' @export

devPlot <-
  function(calcs,...)
{

dots <- list(...)
if (is.null(dots$ylim))dots$ylim <-c(0,max(calcs$sppCiUp,na.rm=TRUE))
if (is.null(dots$xlab))dots$xlab <-"True total"
if (is.null(dots$ylab))dots$ylab <-"Estimated total"
if (is.null(dots$cex))dots$cex <- 0.7
if (is.null(dots$main))dots$main <- ""

plot(calcs$sppPop,calcs$meanSppEst,ylim=dots$ylim,type="n",xlab=dots$xlab,ylab=dots$ylab, main=dots$main)
points(calcs$sppPop,calcs$meanSppEst,pch=16,cex=0.7)
#text(sppPop,meanSppEst,names(sppPop),cex=0.7,pos=rep(c(2,4)10))
text(calcs$sppPop,calcs$meanSppEst,names(calcs$sppPop),cex=dots$cex,pos=4)
segments(calcs$sppPop,calcs$sppCiLo,calcs$sppPop,calcs$sppCiUp)
abline(0,1,col="grey")
return("All Done")
}
#-----------------------------------------------------------------------------
biasPlot <-function(calcs,...)
{
#-----------bias plot------------------------------
dots <- list(...)
if (is.null(dots$ylim))dots$ylim <-c(-20,20)
if (is.null(dots$xlab))dots$xlab <-"Sample size"
if (is.null(dots$ylab))dots$ylab <-"% deviation"
if (is.null(dots$cex))dots$cex <- 0.7

plot(calcs$sppSampSize,calcs$sppBiasEst,type="n",ylim=dots$ylim,xlab=dots$xlab,ylab=dots$ylab)
points(calcs$sppSampSize,calcs$sppBiasEst,pch=16,cex=0.7)
#text(sppSampSize,sppBiasEst,names(sppSampSize),cex=0.7)
text(calcs$sppSampSize,calcs$sppBiasEst,names(calcs$sppSampSize),cex=dots$cex,pos=1)
abline(h=c(-10,-5,5,10),col="grey")
abline(h=c(0),col="grey",lty=2)
#------------------------------------------------------------
return("All Done")
}
