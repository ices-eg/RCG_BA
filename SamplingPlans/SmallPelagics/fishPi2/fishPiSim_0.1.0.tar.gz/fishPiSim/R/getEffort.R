#' Allocate total effort to strata proportional to selected variable(s)
#'
#'
#' @param dat landings dataframe
#' @param strataType Type of stratification, select either "random","sampNow" or"stratified"
#' @param allocateEffortBy Effort will be allocated proportionally. This can by PSU per strata, or the variables 'landWt' or 'fishTripId' can also be selected.
#' @param PSU PSU allocation for the dataframe. Permits check of sufficient PSU for the allocated effort per stratum.
#' @param totalEffort The total effort used across all sampling, this will be divided proportionally across the strata according to parameter define in allocateEffortBy
#' @param minorEffortAllocation (optional) This is a standard value that can be applied to each minor stratum. The resulting sum of these values will be subtracted from the totalEffort
#' @param pusThreshold (optional) This value is the minimum PSU required for a stratum to be included as a sampled stratum. This will be required if the stratum Effort is greater than stratum PSU total. Often required when sampleForeign=FALSE
#'
#' @return vector with effort allocations, named by stratum
#'
#' @examples
#'
#' @author Jessica Craig \email{jessica.craig@gov.scot}
#'
#' @export

getEffort <-
  function (dat, strata = myStratum, strataType = c("random","sampNow","stratified"),
            allocateEffortBy = c("PSU", "landWt", "fishTripId"), PSU = myPSU,
            totalEffort = 711, minorEffortAllocation = 0, psuThreshold = 0)
    {

lengthUnique <-function(x){length(unique(x))}

# stratum PSU totals
psuTotals <- (tapply(myPSU,myStratum,lengthUnique))

if(strataType == "random")
{
  stratumNames <- unique(myStratum)
  myEffort <- totalEffort
  if(is.null(grep("none",stratumNames))){
    names(myEffort) <- stratumNames
    }
  if(!is.null(grep("none",stratumNames))){
    myEffort["none"] <- 0
    names(myEffort) <- stratumNames
    }
}

if(strataType == "sampNow")
{
  presentEffort <-c(0,0,112,80,180,117,120,102)
  if (totalEffort != sum(presentEffort)){presentEffort <- round(presentEffort*(totalEffort/sum(presentEffort)),0)}
  names(presentEffort) <-c("BEL","DEU","DNK","FRA","GBE","GBS","NLD","SWE")

  sampCtry <-names(presentEffort)
  myEffort <-table(myStratum,useNA="always")

  for(i in 1:length(sampCtry)) {
    totals <-table(myStratum)[grep(sampCtry[i],names(table(myStratum,useNA="always")))]
    prop <-totals/sum(totals)
    effort <-presentEffort[grep(sampCtry[i],names(presentEffort))]
    myEffort[names(round(prop*effort))] <-round(prop*effort)
  }

  myEffort[which(myEffort==1)] <-2
  myEffort["none"] <-0
  myEffort <- myEffort[-which(is.na(names(myEffort)))]
}

if(strataType == "stratified"){

  if (allocateEffortBy == "PSU") {
    z <- psuTotals
  }

  if(!(is.na(psuThreshold))){
    # do not include any strata that have fewer PSU than required
    tooFewPSU <- names(psuTotals[psuTotals < psuThreshold])
    myStratum[myStratum %in% tooFewPSU] <- "none"
    psuTotals <- (tapply(myPSU,myStratum,lengthUnique))
    z <- psuTotals
  }

  if(allocateEffortBy %in% names(dat)){

    if(is.character(dat[,c(allocateEffortBy)])){allocationTotals <- (tapply(dat[,c(allocateEffortBy)],myStratum,lengthUnique))}
    if(is.numeric(dat[,c(allocateEffortBy)])){allocationTotals <- (tapply(dat[,c(allocateEffortBy)],myStratum,sum,na.rm = T))}
    z <- allocationTotals
    print(paste(allocateEffortBy,"Totals:"))
    print(z)
  }

  if(is.na(minorEffortAllocation)){

    # allocate effort in proportion to 'allocateEffortBy'
    z <- z[-which(names(z) == "none")]
    effortProportions <- z/sum(z)
    myEffort <-round(effortProportions*totalEffort)
    myEffort[which(myEffort <= 1)] <- 2
    if("none" %in% names(psuTotals)){myEffort["none"] <- 0}
  }

  if(!(is.na(minorEffortAllocation))){

    # allocate effort to minor strata
    majorStrata <- grep("major",names(table(myStratum,useNA="no")),value = TRUE)
    minorStrata <- grep("minor",names(table(myStratum,useNA="no")),value = TRUE)
    minorEffort <- array(minorEffortAllocation,dim=c(length(minorStrata)),dimnames = list(minorStrata))

    #  allocate effort in proportion to 'allocateEffortBy'
    if("none" %in% names(psuTotals)){z <- z[-which(names(z) == "none")]}
    z <- z[-which(names(z) %in% minorStrata)]
    effortProportions <- z/sum(z)
    majorEffort <- round(effortProportions*(totalEffort-sum(minorEffort)))

    # join all efforts together
    myEffort <- c(majorEffort,minorEffort)
    myEffort <- myEffort[sort(names(myEffort))]
    myEffort[which(myEffort <= 1)] <- 2
    if("none" %in% names(psuTotals)){myEffort["none"] <- 0}
  }
}
  myEffort <- myEffort[sort(names(myEffort))]
  psuTotals <- psuTotals[sort(names(psuTotals))]

  if(any(myEffort>psuTotals)){warning("stratum Effort greater than stratum PSU total\n")}

  print("PSU Totals:")
  print(psuTotals)
  print(paste("Effort Totals, proportional to ",allocateEffortBy,":", sep = ""))
  print(myEffort)
  return(myEffort)

}

