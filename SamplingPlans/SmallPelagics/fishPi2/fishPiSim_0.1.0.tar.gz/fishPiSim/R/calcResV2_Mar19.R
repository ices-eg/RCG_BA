#' Calculates summary statistics for simulations
#'
#' Function that calculates summary statistics from the output of the function \code{runSim}, assuming the number of simulations run (nsim) > 1
#'
#' @param resultsObject the results ouput from the simulation
#' @param calcCVpopTrip default FALSE
#' @param fishOfInterest enables calculation of summary statistics specific to a defined list of fish species (FAO code)
#' @param ctryOfInterest enables calculation of summary statistics specific to a defined list of countries
#'
#' @return A list of calculated summary statistics from the simulation output.
#'
#' @examples
#'
#' @author Alastair Pout \email{apout@marlab.ac.uk}
#'
#' @export


calcRes <-
  function(resultsObject,calcCVpopTrip = FALSE, fishOfInterest = NULL, ctryOfInterest = NULL)
{

# functions
lengthUnique <- function(x){length(unique(x))}
asCharacterUnique <- function(x){unique(as.character(x))}

# reassigning a resultsObject for plots and summary statistics
a <- resultsObject
simSppEst <- a$sppEst
simSppSize <- a$sppNumber
simDomSize <- a$domainNumber

pop <-a$pop
#popTrip <-a$popTrip

simTotEst <-a$totalEst
simStrataEst <-a$strataEst
simCtryEst <-a$ctryEst
simDomEst <-a$domainEst

#sppList <- sort(unique(a$pop$sppFAO))
#sppList <- sort(unique(a$pop$sppCode))
#ctryList <- sort(unique(a$pop$landCtry))

sppList <-a$sppList
ctryList <-a$ctryList
domList <-a$domainList

# calculate summary statistics
meanSppEst <- apply(simSppEst[,1,],1,mean,na.rm=T)
sdSppEst <- apply(simSppEst[ ,1,],1,sd,na.rm=T)
sppSampSize <- colMeans(simSppSize)


domSampSize <- colMeans(simDomSize)
domSampSizeCiUp <- apply(simDomSize,2,quantile,0.975,na.rm=T)
domSampSizeCiLo <- apply(simDomSize,2,quantile,0.025,na.rm=T)


meanSdSppEst <- apply(simSppEst[,2,],1,mean,na.rm=T)
ciLoSppEst <- apply(simSppEst[ ,1,],1,quantile,0.025,na.rm=T)
ciUpSppEst <- apply(simSppEst[ ,1,],1,quantile,0.975,na.rm=T)
RSEest <- sdSppEst/meanSppEst

sppPop <- tapply(pop$landWt,pop$sppFac,sum)
sppPopSize <- tapply(pop$fishTripId,pop$sppFac,lengthUnique)
sppBiasEst <- 100*(meanSppEst/sppPop-1)


if(calcCVpopTrip)
{
# this is the population sd and mean of landed weigth by trip
# making the popTrip data frame
# with landWt of spp by trip, one column for each trip
# can be very slow with large data sets
# not sure that it is needed anymore
# needs reshape 2 for the dcast function
library(reshape2)
popTrip <- dcast(a$pop, fishTripId ~ sppFac, value.var="landWt", fill=0, sum)
######################################################
sppPopSD <- apply(popTrip[,sppList],2,sd)
sppPopMean <- apply(popTrip[,sppList],2,mean)
CVpopTrip <- sppPopSD/sppPopMean
}

ctryPop <-tapply(pop$landWt,pop$landCtry,sum)
ciLoCtryEst <- apply(simCtryEst[ ,1,],1,quantile,0.025,na.rm=T)
ciUpCtryEst <- apply(simCtryEst[ ,1,],1,quantile,0.975,na.rm=T)

strataPop <-tapply(pop$landWt,pop$psuStratum,sum)
if(dim(simStrataEst)[1]>1)
{
ciLoStrataEst <- apply(simStrataEst[ ,1,],1,quantile,0.025,na.rm=T)
ciUpStrataEst <- apply(simStrataEst[ ,1,],1,quantile,0.975,na.rm=T)
}

if(dim(simStrataEst)[1]==1)
{
ciLoStrataEst <-apply(simStrataEst[1,,],1,quantile,0.025,na.rm=T)[1]
ciLoStrataEst <-apply(simStrataEst[1,,],1,quantile,0.975,na.rm=T)[1]
#ciLoStrataEst <- apply(simStrataEst[ ,1,],1,quantile,0.025,na.rm=T)
#ciUpStrataEst <- apply(simStrataEst[ ,1,],1,quantile,0.975,na.rm=T)
}


# country Estimates
meanCtryEst <-apply(simCtryEst[,1,],1,mean,na.rm=T)
sdCtryEst <-apply(simCtryEst[ ,1,],1,sd,na.rm=T)
ctryRSEest <- sdCtryEst/meanCtryEst

# domain Estimates
meanDomEst <-apply(simDomEst[,1,],1,mean,na.rm=T)
sdDomEst <-apply(simDomEst[ ,1,],1,sd,na.rm=T)
domainRSEest <- sdDomEst/meanDomEst
ciLoDomEst <- apply(simDomEst[ ,1,],1,quantile,0.025,na.rm=T)
ciUpDomEst <- apply(simDomEst[ ,1,],1,quantile,0.975,na.rm=T)

domainPop <-tapply(pop$landWt,pop$domainFac,sum,na.rm=T)
domBiasEst <- 100*(meanDomEst/domainPop-1)

meanTotEst <-mean(simTotEst[,1])
sdTotEst <-sd(simTotEst[,1])
totRSEest <- sdTotEst/meanTotEst
# mean RSE over fish species and country
sppRSE <- mean(RSEest,na.rm=T)
ctryRSE <- mean(ctryRSEest,na.rm=T)

totBiasEst <-100*(mean((simTotEst[,1]-sum(pop$landWt))/sum(pop$landWt)))
totBiasEstCILo <-100*(quantile((simTotEst[,1]-sum(pop$landWt))/sum(pop$landWt),0.025))
totBiasEstCIUp <-100*(quantile((simTotEst[,1]-sum(pop$landWt))/sum(pop$landWt),0.975))
totBiasEstMedian <-100*(median((simTotEst[,1]-sum(pop$landWt))/sum(pop$landWt)))

# number of sampled trips
meanSampledTrips <- mean(a$fishTripNumber)

pop <- a$pop
nsim <- length(a$sampRowNames)
pop$portFac <- factor(pop$landLoc)
portNames <- levels(pop$portFac)
portPSUsamp <- portSSUsamp <- data.frame(matrix(0,nrow=length(portNames),ncol=nsim))
rownames(portPSUsamp) <- rownames(portSSUsamp) <- portNames

for (i in 1:nsim) {
  samp <- pop[a$sampRowNames[[i]],]
  portPSUsamp[,i] <- tapply(samp$psu,samp$portFac,lengthUnique)
  portSSUsamp[,i] <- tapply(samp$ssu,samp$portFac,lengthUnique)
}
portPSUsamp[is.na(portPSUsamp)] <- 0
portSSUsamp[is.na(portSSUsamp)] <- 0

if (!is.null(fishOfInterest)){

  # % deviation of the fish of interest
  biasFOI <-100*mean((meanSppEst[fishOfInterest]-sppPop[fishOfInterest])/sppPop[fishOfInterest], na.rm = T)
  biasFOICiLo <-100*quantile((meanSppEst[fishOfInterest]-sppPop[fishOfInterest])/sppPop[fishOfInterest],0.025, na.rm = T)
  biasFOICiUp <-100*quantile((meanSppEst[fishOfInterest]-sppPop[fishOfInterest])/sppPop[fishOfInterest],0.975, na.rm = T)

  # relative standard error of the species and estimates of the country total RSE is the SE/mean of the estimates
  RSEsppFOI <-mean(apply(a$sppEst[fishOfInterest,1,],1,sd,na.rm=T)/apply(a$sppEst[fishOfInterest,1,],1,mean,na.rm=T))
  RSEsppFOIciLo <-quantile(apply(a$sppEst[fishOfInterest,1,],1,sd,na.rm=T)/apply(a$sppEst[fishOfInterest,1,],1,mean,na.rm=T),0.025,na.rm=T)
  RSEsppFOIciUp <-quantile(apply(a$sppEst[fishOfInterest,1,],1,sd,na.rm=T)/apply(a$sppEst[fishOfInterest,1,],1,mean,na.rm=T),0.975,na.rm=T)

  # calculating the RSE and quantiles for each spp and country of interest
  RSEresultsFOI <- as.data.frame(matrix(NA,1,((length(fishOfInterest)))))
  names(RSEresultsFOI) <- c(paste("RSE",fishOfInterest, sep="_"))
  for(i in 1:length(fishOfInterest)){RSEresultsFOI[1,i] <- sd(a$sppEst[fishOfInterest[i],1,],na.rm=T)/mean(a$sppEst[fishOfInterest[i],1,],na.rm=T)}

  # SE of the fishOfInterest
  SEsppFOI <-mean((apply(a$sppEst[fishOfInterest,1,],1,sd,na.rm=T))/nsim)

  SEresultsFOI <- as.data.frame(matrix(NA,1,length(fishOfInterest)))
  names(SEresultsFOI) <- c(paste("SE",fishOfInterest, sep="_"))
  for(i in 1:length(fishOfInterest)){SEresultsFOI[1,i] <- sd(a$sppEst[fishOfInterest[i],1,],na.rm=T)/nsim}
}

if (!is.null(ctryOfInterest)){
  RSEctryCOI <-mean(apply(a$ctryEst[ctryOfInterest,1,],1,sd,na.rm=T)/apply(a$ctryEst[ctryOfInterest,1,],1,mean,na.rm=T),na.rm=T)
  RSEctryCOIciLo <-quantile(apply(a$ctryEst[ctryOfInterest,1,],1,sd,na.rm=T)/apply(a$ctryEst[ctryOfInterest,1,],1,mean,na.rm=T),0.025,na.rm=T)
  RSEctryCOIciUp <-quantile(apply(a$ctryEst[ctryOfInterest,1,],1,sd,na.rm=T)/apply(a$ctryEst[ctryOfInterest,1,],1,mean,na.rm=T),0.975,na.rm=T)

  RSEresultsCOI <- as.data.frame(matrix(NA,1,((length(ctryOfInterest)))))
  names(RSEresultsCOI) <- c(paste("RSE",ctryOfInterest, sep="_"))
  for(j in 1:length(ctryOfInterest)){RSEresultsCOI[1,j] <- sd(a$ctryEst[ctryOfInterest[j],1,],na.rm=T)/mean(a$ctryEst[ctryOfInterest[j],1,],na.rm=T)}
}


out <-list("totBiasEst"=totBiasEst,
           "totEst"=simTotEst[,1],
           "sppPop"=sppPop,
           "RSEest"=RSEest,
           "sppRSE"=sppRSE,
           "ctryRSE"=ctryRSE,
           "meanSppEst"=meanSppEst,
           "sppEst"=simSppEst,
           "sppCiLo"=ciLoSppEst,
           "sppCiUp"=ciUpSppEst,
           "sppSampSize"=sppSampSize,
           "sppBiasEst"=sppBiasEst,
           "meanDomEst"=meanDomEst,
           "domCiUp"=ciUpDomEst,
           "domCiLo"=ciLoDomEst,
           "domainPop"=domainPop,
           "domBiasEst"=domBiasEst,
           "domSampSize"=domSampSize,
           "domSampSizeCiLo" = domSampSizeCiLo,
           "domSampSizeCiUp" = domSampSizeCiUp,
           "portPSUsamp"=portPSUsamp,
           "portSSUsamp"=portSSUsamp,
           "totRSEest"=totRSEest,
           "totBiasEstMedian"=totBiasEstMedian,
           "totBiasEstCILo" = totBiasEstCILo,
           "totBiasEstCIUp" = totBiasEstCIUp,
           "meanSampledTrips" = meanSampledTrips)

if (!is.null(fishOfInterest)){
  outFOI <- list("biasFOI" = biasFOI,
                 "biasFOICiLo" = biasFOICiLo,
                 "biasFOICiUp" = biasFOICiUp,
                 "RSEsppFOI"  = RSEsppFOI,
                 "RSEsppFOIciLo" = RSEsppFOIciLo,
                 "RSEsppFOIciUp"  = RSEsppFOIciUp,
                 "RSEresultsFOI" = RSEresultsFOI,
                 "SEsppFOI" = SEsppFOI,
                 "SEresultsFOI" = SEresultsFOI)
  out <- append(out,outFOI)
}

if (!is.null(ctryOfInterest)){
  outCOI <- list("RSEctryCOI" = RSEctryCOI,
                  "RSEctryCOIciLo" = RSEctryCOIciLo,
                  "RSEctryCOIciUp" = RSEctryCOIciUp,
                  "RSEresultsCOI"  = RSEresultsCOI)
  out <- append(out,outCOI)
}

cat("Simulation summary statistics complete\n")

return(out)
}
