#' Sets up the data ready for running simulations
#'
#' Function that add variables to the landings dataframe in preparation for running the simulations.
#' It sets up the primary sampling units (PSU), the secondary sampling units (SSU).
#' It also checks the availability of sufficient PSU for the effort allocated per stratum
#'
#'
#' @param data landings dataframe
#' @param psu primary sampling unit, e.g. "fishTripId" or "siteXday"
#' @param psuStratum vector with PSU per named stratum
#' @param stratumEffort vector with effort allocation per named stratum
#' @param variable tbc
#' @param domains variable defining the domains in the landings dataframe
#'
#'
#' @return
#'
#' @examples
#'
#' @author Alastair Pout \email{apout@marlab.ac.uk}
#'
#' @export

setUpData <-function(data,psu="fishTripId",psuStratum,stratumEffort,variable,domains)
{
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# V2 as of 7-8-2018

# setUpData
# function that takes the fishPi 2 data frame
# and assignes various columns depending on the user specifications
# calculates stratum totals

# note
# variable is passed as an argument but is nowhere used or returned.
# Mar19 - JC added coverage calculations


#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

xx <-data

lengthUnique <-function(x){length(unique(x))}

if(!(psu %in% c("fishTripId","vslId","siteXday")))
{cat("psu expected to be fishTripId,vslId,or siteXday\n")}

if(psu %in% "fishTripId")
{
xx$psu <-xx$fishTripId
xx$ssu <-NA
cat("psu is fishTripId, ssu is NA\n")
}
if(psu %in% "vslId")
{
xx$psu <-xx$vslId
xx$ssu <-xx$fishTripId
cat("psu is vslId, ssu is fishTripId\n")
}
if(psu %in% "siteXday")
{
xx$psu <-paste(xx$landLoc,xx$landDate,sep="_")
xx$ssu <-paste(xx$fishTripId)
cat("psu is siteXday, ssu is fishTripId\n")
}






#  the PSU stratum
if(missing(psuStratum)){stop("psuStratum missing")}


if(length(psuStratum)==1 && toupper(psuStratum)=="RANDOM")
{
xx$psuStratum <-"ALL"
cat("Random sampling of psu with no stratification\n")
}

if(all(psuStratum %in% names(xx)))
{
if(length(psuStratum)>1)
{
psuST <-paste(psuStratum,collapse="_")
newvar <-apply(xx[,psuStratum],1,paste,collapse="_")
xx$psuStratum <-newvar
stratVar <-psuST
cat("psuStratum is ",psuST,"\n")
}
if(length(psuStratum)==1)
{xx$psuStratum <-xx[,psuStratum]
stratVar <-psuStratum
cat("psuStratum is ",psuStratum,"\n")
}}

if(!(all(psuStratum %in% names(xx))))
{
if(length(psuStratum)==length(xx[,1]))
{
xx$psuStratum <-as.character(psuStratum)
cat("psuStratum is a new variable ",head(xx$psuStratum),"....\n")
}
if(toupper(psuStratum) != "RANDOM" && length(psuStratum)!=length(xx[,1]))
{
stop("psuStratum expected to be of length ",length(xx[,1]))}
}

# we make all psuStratum names uppercase
xx$psuStratum <-toupper(xx$psuStratum)

#stratumEffort

# first we make all statumEffort names uppercase
names(stratumEffort) <-toupper(names(stratumEffort))
if(length(stratumEffort)!=lengthUnique(xx$psuStratum))
{stop("stratumEffort should be the same length as the number of strata\n")}
if(is.null(names(stratumEffort)))
{stop("stratumEffort should be a named vector \n")}
cat("stratum Names are: ",names(stratumEffort),"\n")
cat("stratumEffort is: ",stratumEffort,"\n")



# the stratum totals are:
psuStratumN <-tapply(xx$psu,xx$psuStratum,lengthUnique)
actualStrata <-names(psuStratumN)
cat("actual Strata are",actualStrata,"\n")
if(!(all(actualStrata %in% names(stratumEffort)))){
stop("stratumEffort is missing for some strata\n") }


# the expected stratum samples sizes are:
xx$psuPlanned <-stratumEffort[match(xx$psuStratum,names(stratumEffort))]


# and we map those values to every row in the data frame
xx$psuTotal <-psuStratumN[match(xx$psuStratum,names(psuStratumN))]

cat("stratum Totals are:",psuStratumN ,"\n")

# check strata are in the same order
stratumEffort <- stratumEffort[sort(names(stratumEffort))]
psuStratumN <- psuStratumN[sort(names(psuStratumN))]

if(any(stratumEffort>psuStratumN))
warning("stratum Effort greater than stratum total\n")

if (sampleForeignVessels == FALSE) {
# for the non sampling of foreign vessels we check that the PSU totals are not less than the planned effort
psuStratumNOwn <-tapply(xx$psu[xx$landType=="own"],xx$psuStratum[xx$landType=="own"],lengthUnique)
cat("stratum Totals for own vessels are:",psuStratumNOwn ,"\n")
if(any(stratumEffort>psuStratumNOwn))
warning("stratum Effort greater than stratum total when sampling only own vessels. Apply a PSU thresold in the 'getEffort' function to ensure sufficent PSU/stratum \n")
}

# we factorise the sppFAO codes and make column sppFac
sppList <- sort(unique(xx$sppFAO))
xx$sppFac <- factor(xx$sppFAO,levels=sppList,ordered=TRUE)

# if no domains are specified then we default to estimating for the sppFAO
if(missing(domains))
{
xx$domainName <-xx[,"sppFAO"]
domainNames <-"sppFAO"
cat("no domains specified, using sppFAO\n")

}
if(!(missing(domains)))
{
#xx$domainName <-ifelse(length(domains==1),xx[,domains],apply(xx[,domains],1,paste,collapse="."))
domainNames <-domains
if(length(domains)>1)
{
xx$domainName <-apply(xx[,domains],1,paste,collapse=".")
domainNames <-paste(domains,collapse="+")
}
if(length(domains)==1)
{
xx$domainName <-xx[,domains]
domainNames <-domains
}
cat(domains,"specified for estimation\n")
}
domainList <- sort(unique(xx$domainName))
xx$domainFac <- factor(xx$domainName,levels=domainList,ordered=TRUE)

# coverage measures
if (sampleForeignVessels == TRUE){
# psu coverage
sampPSU <-sum(psuStratumN[stratumEffort>0])
totalPSU <-sum(psuStratumN)
coveragePSU <- round(100*sampPSU/totalPSU,2)

# landed weight
sampStrata <-toupper(names(stratumEffort[stratumEffort>0]))
sampTonnage <-sum(xx$landTonnage[which(xx$psuStratum %in% sampStrata)])
totalTonnage <-sum(xx$landTonnage)
coverageTonnage <- round(100*(sampTonnage/totalTonnage),2)

# trips
sampTrips <-lengthUnique(xx$fishTripId[which(xx$psuStratum %in% sampStrata)])
totalTrips <-lengthUnique(xx$fishTripId)
coverageTrips <- round(100*(sampTrips/totalTrips),2)
}
if (sampleForeignVessels == FALSE){
  # PSU
  sampPSU <-sum(psuStratumNOwn[stratumEffort>0])
  totalPSU <-sum(psuStratumN)
  coveragePSU <- round(100*sampPSU/totalPSU,2)

  # landed weight
  sampStrata <-toupper(names(stratumEffort[stratumEffort>0]))
  sampTonnage <-sum(xx$landTonnage[which(xx$psuStratum %in% sampStrata & xx$landType == "own")])
  totalTonnage <-sum(xx$landTonnage)
  coverageTonnage <- round(100*(sampTonnage/totalTonnage),2)

  # trips
  sampTrips <-lengthUnique(xx$fishTripId[which(xx$psuStratum %in% sampStrata & xx$landType == "own")])
  totalTrips <-lengthUnique(xx$fishTripId)
  coverageTrips <- round(100*(sampTrips/totalTrips),2)
}

cat(paste("Percent coverage of PSU:", coveragePSU,"\n"))
cat(paste("Percent coverage of tonnage:", coverageTonnage,"\n"))
cat(paste("Percent coverage of trips:", coverageTrips,"\n"))

if (sampleForeignVessels == FALSE) {
  out <-list("data"=xx,"psu"=psu,"psuStratumN"=psuStratumN, "psuStratumNOwn"=psuStratumNOwn,"stratumEffort"=stratumEffort,"domainNames"=domainNames,
            "coveragePSU" = coveragePSU, "coverageTonnage" = coverageTonnage, "coverageTrips" = coverageTrips)
} else {
out <-list("data"=xx,"psu"=psu,"psuStratumN"=psuStratumN,"stratumEffort"=stratumEffort,"domainNames"=domainNames,
           "coveragePSU" = coveragePSU, "coverageTonnage" = coverageTonnage, "coverageTrips" = coverageTrips)
}

return(out)
#return("all done")
}


