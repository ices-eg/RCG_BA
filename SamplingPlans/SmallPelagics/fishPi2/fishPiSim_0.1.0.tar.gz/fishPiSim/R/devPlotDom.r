#' Variance plot by domain
#'
#'
#' @param calcs list of summary statistics output from the function \code{"calcRes"}
#'
#' @return Variance plot by domain
#'
#' @examples
#'
#' @author Alastair Pout \email{apout@marlab.ac.uk} and Jessica Craig \email{jessica.craig@gov.scot}
#'
#' @export

devPlotDom <-
  function(calcs,...)
{
  dots <- list(...)
  if (is.null(dots$ylim))dots$ylim <-c(0,max(calcs$domCiUp,na.rm=TRUE))
  if (is.null(dots$xlab))dots$xlab <-"True total"
  if (is.null(dots$ylab))dots$ylab <-"Estimated total"
  if (is.null(dots$cex))dots$cex <- 0.5

  plot(calcs$domainPop,calcs$meanDomEst,ylim=dots$ylim,type="n",xlab=dots$xlab,ylab=dots$ylab)
  points(calcs$domainPop,calcs$meanDomEst,pch=16,cex=0.7)
  text(calcs$domainPop,calcs$meanDomEst,names(calcs$domainPop),cex=dots$cex,pos=4)
  segments(calcs$domainPop,calcs$domCiLo,calcs$domainPop,calcs$domCiUp)
  abline(0,1,col="grey")
  return("All Done")
}
