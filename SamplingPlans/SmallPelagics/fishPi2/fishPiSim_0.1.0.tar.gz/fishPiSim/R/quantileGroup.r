#' Ranks and groups sampling units
#'
#' Function that ranks a sampling unit by a numeric auxilary variable and divides the sampling unit into n groupings defined by the proportion of the ranked variable
#'
#' @param sampUnit tbc
#' @param value tbc
#' @param breaks tbc
#' @param labels tbc
#'
#' @return tbc
#'
#' @examples
#'
#' @author Alastair Pout \email{apout@marlab.ac.uk}
#'
#' @export

quantileGroup <-
  function(sampUnit,value,breaks=c(0,0.5,0.8,1),labels=c("small","med","big"))
{

dat <-sort(tapply(value,sampUnit,sum,na.rm=T))
datnames <- names(dat)
datranked <- (cumsum(as.numeric(dat))/sum(as.numeric(dat)))
strata <-cut(datranked,breaks=breaks,labels=labels)
names(strata) <-datnames
stratum <-strata[sampUnit]

out <-list(sampUnit=sampUnit,value=value,stratum=stratum)
return(out)
}

